<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ChargeInvoiceModel extends Model
{
    //
    protected $table = 'chargeinvoice';
    protected $primaryKey = 'chargeinvoice_id';
}
