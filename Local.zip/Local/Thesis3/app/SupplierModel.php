<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SupplierModel extends Model
{
    //
    protected $table = 'supplier';
    protected $primaryKey = 'supplier_id';
}
