<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SummaryModel extends Model
{
    //
    protected $table = 'summary';
    protected $primaryKey = 'summary_id';
    
}
