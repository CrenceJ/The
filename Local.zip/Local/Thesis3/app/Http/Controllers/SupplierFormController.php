<?php

namespace App\Http\Controllers;
use App\ServicesModel;
use App\ClientsModel;
use App\SupplierModel;
use App\SalesModel;
use App\OrdersModel;
use App\OrderDetailsModel;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Helper;
use Auth;
use Session;
use DB;
use Carbon\Carbon;

class SupplierFormController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $currentUser = Helper::staticInfo();

        return view('Admin.SupplierForm',compact('currentUser'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
           
            $validator = Validator::make($request->all(), [
            // 'image' => 'required|image|mimes:jpg,jpeg,png,gif|max:4090',
            'name'=> 'required',
            'address' => 'required',
            'contact' => 'required|regex:/(09)[0-9]{9}/',
            'person' => 'required'

        ]);

            if ($validator->fails()) {
            Session::flash('error', $validator->messages()->first());
            return redirect()->back()->withInput();
       }

        date_default_timezone_set('Asia/Manila');
        $supplier = new SupplierModel;
        $supplier->supplier_name = $request->input('name');
        $supplier->supplier_address = $request->input('address');
        $supplier->supplier_contactno = $request->input('contact');
        $supplier->supplier_contactperson = $request->input('person');
        $supplier->save();
        return redirect()->back()->with('success','Added Successfully!',compact('supplier'))->withInput();
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
